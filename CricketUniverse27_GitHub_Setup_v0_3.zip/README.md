# CRICKET UNIVERSE 27 — Android-first Unity prototype

Original cricket game prototype starter kit for Unity/C#. Includes mobile UI hooks for swing/bowl, basic ball physics, delivery launching, score tracking, and a simple HUD.

## Status
Prototype source kit only. It is not a complete Unity project and is not a compiled APK or Windows executable.

## Android-only workflow
Use GitHub from the phone to store the source. A supported Windows/macOS/Linux desktop Unity Editor session (local, remote, or a trusted collaborator's machine) is still required to create and configure the actual Unity project. Once the complete Unity project is in source control, investigate Unity Build Automation for cloud builds.

See `GITHUB_SETUP.md` for phone-based repository setup.
